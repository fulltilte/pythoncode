#((x & A !=0) <= (x & 55 = 33))  (x & 112 != 16)

for a in range(1, 1001):
    res = True
    for x in range(1, 1001):
        result = ((x & a != 0) <= (x & 55 == 33)) or (x & 112 != 16)
        res *= result
    if res:
        print(a)