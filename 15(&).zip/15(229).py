#(x & A =0)  ((x & 69 = 4)  (x & 118 = 6))

for a in range(1, 1001):
    res = True
    for x in range(1, 1001):
        result = (x & a == 0) or ((x & 69 == 4) <= (x & 118 == 6))
        res *= result
    if res:
        print(a)
        break