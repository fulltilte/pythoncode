# (ДЕЛ(x, 40)  ДЕЛ(x, 64))   ДЕЛ(x, A)
for a in range(1, 1001):
    res = True
    for x in range(1, 10001):
        result = ((x % 40 == 0) or (x % 64 == 0)) <= (x % a == 0)
        res *= result
    if res:
        print(a)
