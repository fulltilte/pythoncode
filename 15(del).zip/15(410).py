#ДЕЛ(A, 3) /\ (ДЕЛ(220, x) → (¬ДЕЛ(A, x) → ¬ДЕЛ(550, x)))
min_ = 10000
for a in range(1, 1001):
    res = True
    for x in range(1, 1001):
        result = (a % 3 == 0) and ((220 % x == 0) <= ((a % x != 0) <= (550 % x != 0)))
        res *= result
    if res:
        print(a)
        break