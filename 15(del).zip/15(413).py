#ДЕЛ(A, 12) /\ (ДЕЛ(530, x) → (¬ДЕЛ(A, x) → ¬ДЕЛ(170, x)))
count = 0
for a in range(1,1001):
    res = True
    for x in range(1,1001):
        f = (a % 12 == 0) and ((530 % x == 0) <= ((a % x != 0) <= (170 % x != 0)))
        res *= f
    if res:
        count += 1
print(count)

