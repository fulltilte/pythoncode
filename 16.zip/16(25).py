def F(n):
    global count
    #print('*')
    count += 1
    if n >= 1:
        #print('*')
        count += 1
        F(n - 1)
        F(n // 2)
count = 0
n = 140
F(n)
print(count)