def F(n):
    if n == 0:
        return 0
    if n > 0 and n % 2 == 0:
        return F(n // 2) + 3
    if n > 0 and n % 2 != 0:
        return 2 * F(n - 1) + 1
list_ = []
for n in range(1, 1001):
    res = F(n)
    list_.append(res)

clearlist_ = set(list_)
count = len(clearlist_)
print(count)